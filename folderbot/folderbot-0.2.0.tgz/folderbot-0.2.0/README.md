# Folder Bot v0.2.0

설치: bash install.sh [루트 폴더]  ·  실행: folderbot start
자세한 절차: RUNBOOK-mini.md
